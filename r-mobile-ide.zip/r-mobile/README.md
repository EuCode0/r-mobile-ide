# R Mobile IDE — Deploy no Railway (grátis, pelo celular)

## Como colocar no ar em 10 minutos

### Passo 1 — Suba o código no GitHub

1. Acesse **github.com** no celular e crie uma conta (gratuita)
2. Crie um repositório novo chamado `r-mobile-ide`
3. Faça upload dos arquivos deste ZIP:
   - Clique em "uploading an existing file"
   - Selecione todos os arquivos descompactados
   - Clique em "Commit changes"

### Passo 2 — Deploy no Railway

1. Acesse **railway.app** no celular
2. Clique em "Start a New Project"
3. Escolha "Deploy from GitHub repo"
4. Autorize o GitHub e selecione `r-mobile-ide`
5. Railway detecta automaticamente o `railway.json` e faz o deploy

### Passo 3 — Configurar domínio grátis

1. No painel do Railway, clique no seu projeto
2. Vá em "Settings" → "Domains"
3. Clique em "Generate Domain"
4. Você receberá um link tipo: `r-mobile-ide.up.railway.app`

### Passo 4 — Instalar como app no Android

1. Abra o link no **Chrome** do Android
2. Toque nos 3 pontinhos (⋮) no canto superior direito
3. Toque em **"Adicionar à tela inicial"**
4. Confirme — a IDE aparece como app no seu celular!

## Variáveis de ambiente (opcional, para IA)

No painel do Railway → Variables, adicione:
```
ANTHROPIC_API_KEY=sua-chave-aqui
```
Sem isso, a IDE funciona normalmente — só o assistente de IA fica desativado.

## Limites do plano gratuito Railway
- 500 horas/mês de execução (suficiente para uso pessoal)
- 512MB RAM
- Deploy automático a cada push no GitHub

## Alternativas gratuitas
- **Vercel**: vercel.com → ainda mais simples, só arrastar a pasta `frontend`
- **Render**: render.com → similar ao Railway
