/**
 * hybrid-executor.ts
 * Decide automaticamente onde executar o código R:
 *   - LOCAL:  WebR + WASM (rápido, offline, scripts leves)
 *   - CLOUD:  Servidor Docker (pacotes pesados, computação intensa, GPU)
 *   - CACHE:  Resultado armazenado (sem internet, idempotente)
 */

import { webREngine, type ExecResult } from './webr-engine';
import { openDB, IDBPDatabase } from 'idb';
import axios from 'axios';

// ---- Classificador de complexidade ----------------------------------------

const HEAVY_PACKAGES = new Set([
  'tensorflow','keras','torch','caret','randomForest','xgboost','lightgbm',
  'Seurat','DESeq2','edgeR','limma','GenomicRanges','BiocParallel',
  'Rfast','MASS','nnet','e1071','glmnet','survival',
]);

const HEAVY_PATTERNS = [
  /parallel::/,
  /mclapply|mcmapply|parLapply/,
  /future::|plan\(/,
  /Sys\.sleep\(\s*[1-9]/,
  /for\s*\(.*\)\s*\{[\s\S]{500,}\}/,   // loop grande
];

type ExecMode = 'local' | 'cloud' | 'cache';

function classifyCode(code: string): { mode: ExecMode; reason: string } {
  // Sem internet → cache ou local
  if (!navigator.onLine) {
    return { mode: 'local', reason: 'offline: usando motor local WebR' };
  }

  // Verifica pacotes pesados
  const loadedPkgs = [...HEAVY_PACKAGES].filter(pkg =>
    new RegExp(`library\\(${pkg}\\)|require\\(${pkg}\\)|${pkg}::`).test(code)
  );
  if (loadedPkgs.length > 0) {
    return { mode: 'cloud', reason: `pacote pesado detectado: ${loadedPkgs.join(', ')}` };
  }

  // Verifica padrões de código intensivo
  const heavyPattern = HEAVY_PATTERNS.find(p => p.test(code));
  if (heavyPattern) {
    return { mode: 'cloud', reason: 'computação paralela ou loop intensivo detectado' };
  }

  // Código grande (> 200 linhas) → cloud
  if (code.split('\n').length > 200) {
    return { mode: 'cloud', reason: 'script grande: usando servidor remoto' };
  }

  return { mode: 'local', reason: 'script leve: executando localmente (WebR)' };
}

// ---- Cache IndexedDB -------------------------------------------------------

let db: IDBPDatabase | null = null;

async function getDB(): Promise<IDBPDatabase> {
  if (db) return db;
  db = await openDB('r-mobile-cache', 1, {
    upgrade(d) {
      d.createObjectStore('results', { keyPath: 'hash' });
      d.createObjectStore('files', { keyPath: 'id' });
    },
  });
  return db;
}

async function hashCode(code: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(code));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getCached(hash: string): Promise<ExecResult | null> {
  try {
    const d = await getDB();
    const entry = await d.get('results', hash);
    if (!entry) return null;
    // Cache válido por 1h
    if (Date.now() - entry.timestamp > 3600_000) {
      await d.delete('results', hash);
      return null;
    }
    return entry.result;
  } catch { return null; }
}

async function setCached(hash: string, result: ExecResult): Promise<void> {
  try {
    const d = await getDB();
    await d.put('results', { hash, result, timestamp: Date.now() });
  } catch {}
}

// ---- Executor Cloud --------------------------------------------------------

async function executeCloud(code: string, sessionId: string): Promise<ExecResult> {
  const API = process.env.NEXT_PUBLIC_API_URL || '/api';
  const start = Date.now();
  try {
    const { data } = await axios.post(
      `${API}/execute`,
      { code, sessionId },
      {
        timeout: 120_000,
        headers: { 'Content-Type': 'application/json' },
      }
    );
    return {
      stdout: data.stdout || [],
      stderr: data.stderr || [],
      warnings: data.warnings || [],
      plots: data.plots || [],
      error: data.error || null,
      duration: Date.now() - start,
    };
  } catch (err: any) {
    // Fallback para local se cloud falhar
    console.warn('[HybridExecutor] Cloud falhou, tentando local:', err.message);
    return webREngine.execute(code);
  }
}

// ---- Interface pública -----------------------------------------------------

export type ExecOptions = {
  sessionId?: string;
  forceMode?: ExecMode;
  useCache?: boolean;
  onModeDecision?: (mode: ExecMode, reason: string) => void;
};

export async function executeR(code: string, opts: ExecOptions = {}): Promise<ExecResult> {
  const { sessionId = 'default', forceMode, useCache = true, onModeDecision } = opts;

  // Garante que WebR esteja inicializado
  if (!webREngine.ready) {
    await webREngine.init();
  }

  const classification = forceMode
    ? { mode: forceMode, reason: `modo forçado: ${forceMode}` }
    : classifyCode(code);

  onModeDecision?.(classification.mode, classification.reason);

  // Tenta cache para resultados determinísticos
  if (useCache && classification.mode !== 'cloud') {
    const hash = await hashCode(code);
    const cached = await getCached(hash);
    if (cached) {
      onModeDecision?.('cache', 'resultado em cache (offline ou repetido)');
      return cached;
    }

    const result = await webREngine.execute(code);
    // Só cacheia se não teve erro
    if (!result.error) await setCached(hash, result);
    return result;
  }

  // Execução local
  if (classification.mode === 'local') {
    return webREngine.execute(code);
  }

  // Execução cloud
  return executeCloud(code, sessionId);
}

export { classifyCode };
export type { ExecMode };
