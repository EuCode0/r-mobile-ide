/**
 * webr-engine.ts
 * Motor local de execução R via WebAssembly (WebR).
 * Roda 100% no browser, sem servidor. Usado para scripts leves e modo offline.
 */

import { WebR, REnvironment } from '@webr/webr';

export type ExecResult = {
  stdout: string[];
  stderr: string[];
  warnings: string[];
  plots: string[];   // SVG strings de gráficos gerados
  error: string | null;
  duration: number;
};

class WebREngine {
  private webr: WebR | null = null;
  private globalEnv: REnvironment | null = null;
  private isReady = false;
  private initPromise: Promise<void> | null = null;

  /** Inicia o runtime WebR (faz download do WASM ~5MB na primeira vez) */
  async init(onProgress?: (msg: string) => void): Promise<void> {
    if (this.initPromise) return this.initPromise;

    this.initPromise = (async () => {
      onProgress?.('Iniciando motor R local (WebAssembly)...');

      this.webr = new WebR({
        baseUrl: 'https://webr.r-wasm.org/latest/',
        serviceWorkerUrl: '/webr-serviceworker.js',
      });

      await this.webr.init();
      onProgress?.('R iniciado. Carregando ambiente...');

      // Captura o ambiente global para persistir variáveis entre execuções
      this.globalEnv = await this.webr.globalEnv;

      // Pré-carrega pacotes básicos
      await this.webr.evalRVoid(`
        options(warn = 1)
        suppressMessages({
          library(methods)
          library(stats)
          library(utils)
          library(graphics)
          library(grDevices)
        })
      `);

      // Configura captura de gráficos como SVG
      await this.webr.evalRVoid(`
        .r_mobile_plots <- list()
        .r_mobile_capture_plot <- function() {
          tmp <- tempfile(fileext = ".svg")
          svg(tmp, width = 7, height = 5)
          tryCatch({
            replayPlot(recordPlot())
          }, error = function(e) NULL)
          dev.off()
          if (file.exists(tmp)) readLines(tmp) else character(0)
        }
      `);

      this.isReady = true;
      onProgress?.('Motor R pronto.');
    })();

    return this.initPromise;
  }

  /** Executa código R e retorna stdout, stderr, warnings e plots */
  async execute(code: string, timeoutMs = 30000): Promise<ExecResult> {
    if (!this.webr || !this.isReady) {
      throw new Error('WebR não inicializado. Chame init() primeiro.');
    }

    const start = Date.now();
    const stdout: string[] = [];
    const stderr: string[] = [];
    const warnings: string[] = [];
    const plots: string[] = [];

    // Configura captura de output
    const shelter = await this.webr.Shelter.create();

    try {
      await this.webr.evalRVoid('dev.new()', { env: this.globalEnv! });

      // Executa o código com timeout
      const result = await Promise.race([
        this.webr.evalR(
          `
          local({
            withCallingHandlers(
              tryCatch({
                ${code}
              }, error = function(e) {
                cat(paste0("__ERROR__:", conditionMessage(e), "\n"), file = stderr())
              }),
              warning = function(w) {
                cat(paste0("__WARN__:", conditionMessage(w), "\n"), file = stderr())
                invokeRestart("muffleWarning")
              },
              message = function(m) {
                cat(paste0("__MSG__:", conditionMessage(m)), file = stdout())
                invokeRestart("muffleMessage")
              }
            )
          })
          `,
          { env: this.globalEnv! }
        ),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`Timeout: execução excedeu ${timeoutMs / 1000}s`)), timeoutMs)
        ),
      ]);

      // Captura plots
      const plotResult = await this.webr.evalR(
        `
        if (dev.cur() > 1) {
          tmp <- tempfile(fileext = ".svg")
          dev.copy(svg, tmp, width = 7, height = 5)
          dev.off()
          if (file.exists(tmp)) paste(readLines(tmp), collapse = "\n") else ""
        } else { "" }
        `,
        { env: this.globalEnv! }
      );
      const plotStr = await plotResult.toJs();
      if (typeof plotStr === 'string' && plotStr.includes('<svg')) {
        plots.push(plotStr);
      }

      // Lê saídas capturadas
      const output = await this.webr.flush();
      for (const msg of output) {
        if (msg.type === 'stdout') {
          const line = msg.data as string;
          if (line.startsWith('__WARN__:')) {
            warnings.push(line.replace('__WARN__:', '').trim());
          } else if (line.startsWith('__MSG__:')) {
            stdout.push(line.replace('__MSG__:', '').trim());
          } else {
            stdout.push(line);
          }
        } else if (msg.type === 'stderr') {
          const line = msg.data as string;
          if (line.startsWith('__ERROR__:')) {
            stderr.push(line.replace('__ERROR__:', '').trim());
          } else if (line.startsWith('__WARN__:')) {
            warnings.push(line.replace('__WARN__:', '').trim());
          } else {
            stderr.push(line);
          }
        }
      }

      return {
        stdout,
        stderr: stderr.filter(l => !l.startsWith('__ERROR__')),
        warnings,
        plots,
        error: stderr.find(l => l) || null,
        duration: Date.now() - start,
      };
    } catch (err: any) {
      return {
        stdout,
        stderr,
        warnings,
        plots,
        error: err.message || String(err),
        duration: Date.now() - start,
      };
    } finally {
      shelter.purge();
    }
  }

  /** Instala pacote R localmente via WebR */
  async installPackage(pkg: string, onLog?: (msg: string) => void): Promise<boolean> {
    if (!this.webr || !this.isReady) throw new Error('WebR não pronto');
    try {
      onLog?.(`Instalando ${pkg}...`);
      await this.webr.installPackages([pkg]);
      await this.webr.evalRVoid(`library(${pkg})`);
      onLog?.(`✓ ${pkg} instalado`);
      return true;
    } catch (e: any) {
      onLog?.(`✗ Erro ao instalar ${pkg}: ${e.message}`);
      return false;
    }
  }

  /** Retorna lista de variáveis no ambiente global */
  async getEnvironmentVars(): Promise<{ name: string; type: string; preview: string }[]> {
    if (!this.webr || !this.isReady) return [];
    try {
      const result = await this.webr.evalR(`
        vars <- ls(envir = .GlobalEnv)
        if (length(vars) == 0) data.frame(name=character(0), type=character(0), preview=character(0))
        else {
          data.frame(
            name = vars,
            type = sapply(vars, function(v) class(get(v, envir=.GlobalEnv))[1]),
            preview = sapply(vars, function(v) {
              obj <- get(v, envir=.GlobalEnv)
              if (is.data.frame(obj)) paste0("data.frame [", nrow(obj), "x", ncol(obj), "]")
              else if (is.vector(obj) && length(obj) > 1) paste0("[", paste(head(obj,3), collapse=", "), "...]")
              else paste0(obj)[1]
            }),
            stringsAsFactors = FALSE
          )
        }
      `, { env: this.globalEnv! });
      const df = await result.toJs();
      return (df.values?.[0]?.values || []).map((_: any, i: number) => ({
        name: df.values[0].values[i],
        type: df.values[1].values[i],
        preview: df.values[2].values[i],
      }));
    } catch { return []; }
  }

  /** Autocomplete para o editor */
  async getCompletions(prefix: string): Promise<string[]> {
    if (!this.webr || !this.isReady) return [];
    try {
      const result = await this.webr.evalR(
        `utils:::.completeToken(${JSON.stringify(prefix)})$completions`,
        { env: this.globalEnv! }
      );
      return await result.toJs() as string[];
    } catch { return []; }
  }

  /** Limpa o ambiente global */
  async clearEnvironment(): Promise<void> {
    if (!this.webr || !this.isReady) return;
    await this.webr.evalRVoid('rm(list=ls(envir=.GlobalEnv), envir=.GlobalEnv)');
  }

  get ready() { return this.isReady; }
}

// Singleton — uma instância por aba do browser
export const webREngine = new WebREngine();
export type { WebREngine };
