/**
 * components/console/RConsole.tsx
 * Console estilo terminal com stdout, stderr, warnings coloridos,
 * histórico de comandos e indicador de modo de execução (local/cloud/cache).
 */

'use client';

import { useEffect, useRef, useState, KeyboardEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useIDEStore, type ConsoleLine } from '../../store/ide-store';
import { executeR } from '../../lib/hybrid-executor';

// ---- Estilos por tipo de linha ---------------------------------------------

const LINE_STYLES: Record<ConsoleLine['type'], string> = {
  input:   'text-blue-400 font-mono',
  output:  'text-gray-200 font-mono',
  error:   'text-red-400 font-mono',
  warning: 'text-yellow-400 font-mono',
  info:    'text-cyan-400 font-mono text-xs',
  system:  'text-gray-500 font-mono text-xs italic',
};

const LINE_PREFIXES: Record<ConsoleLine['type'], string> = {
  input:   '> ',
  output:  '  ',
  error:   '✗ ',
  warning: '⚠ ',
  info:    'ℹ ',
  system:  '· ',
};

// ---- Comandos rápidos (barra de atalhos) ------------------------------------

const QUICK_COMMANDS = [
  { label: 'ls()', code: 'ls()' },
  { label: 'head()', code: 'head(df)' },
  { label: 'str()', code: 'str(df)' },
  { label: 'summary()', code: 'summary(df)' },
  { label: 'dim()', code: 'dim(df)' },
  { label: 'sessionInfo()', code: 'sessionInfo()' },
  { label: 'rm(list=ls())', code: 'rm(list=ls())' },
  { label: 'graphics.off()', code: 'graphics.off()' },
];

// ---- Formatação de timestamp ------------------------------------------------

function fmtTime(ts: number): string {
  return new Date(ts).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

// ---- Componente principal ---------------------------------------------------

type Props = {
  onClearEnv?: () => void;
};

export function RConsole({ onClearEnv }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [history, setHistory] = useState<string[]>([]);
  const [historyIdx, setHistoryIdx] = useState(-1);
  const [showTimestamps, setShowTimestamps] = useState(false);

  const {
    consoleLines, consoleInput, isExecuting, execMode, execModeReason,
    addConsoleLine, clearConsole, setConsoleInput, setExecuting,
    addPlot, setEnvVars, sessionId, webRReady, fontSize,
  } = useIDEStore();

  // Auto-scroll ao fim
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [consoleLines]);

  // Executa código no console
  const runCode = async (code: string) => {
    if (!code.trim() || isExecuting) return;

    const trimmed = code.trim();

    // Adiciona ao histórico
    setHistory(h => [trimmed, ...h.slice(0, 99)]);
    setHistoryIdx(-1);

    addConsoleLine('input', trimmed);
    setConsoleInput('');
    setExecuting(true);

    try {
      const result = await executeR(trimmed, {
        sessionId,
        onModeDecision: (mode, reason) => {
          setExecuting(true, mode, reason);
          addConsoleLine('system', `[${mode.toUpperCase()}] ${reason}`);
        },
      });

      // Exibe stdout
      result.stdout.forEach(line => {
        if (line.trim()) addConsoleLine('output', line);
      });

      // Exibe warnings
      result.warnings.forEach(w => addConsoleLine('warning', w));

      // Exibe erros
      if (result.error) {
        addConsoleLine('error', `Erro: ${result.error}`);
      } else if (result.stderr.length) {
        result.stderr.forEach(l => {
          if (l.trim()) addConsoleLine('error', l);
        });
      }

      // Registra plots gerados
      result.plots.forEach(svg => addPlot(svg, trimmed));

      // Atualiza variáveis de ambiente
      const { webREngine } = await import('../../lib/webr-engine');
      if (webREngine.ready) {
        const vars = await webREngine.getEnvironmentVars();
        setEnvVars(vars);
      }

      // Info de performance
      addConsoleLine('system', `Concluído em ${result.duration}ms`);
    } catch (err: any) {
      addConsoleLine('error', `Erro interno: ${err.message}`);
    } finally {
      setExecuting(false);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      runCode(consoleInput);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const next = Math.min(historyIdx + 1, history.length - 1);
      setHistoryIdx(next);
      setConsoleInput(history[next] ?? '');
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      const next = Math.max(historyIdx - 1, -1);
      setHistoryIdx(next);
      setConsoleInput(next === -1 ? '' : history[next] ?? '');
    } else if (e.key === 'Tab') {
      e.preventDefault();
      // TODO: autocomplete no console
    }
  };

  // Badge do modo de execução
  const modeBadge = {
    local: { text: 'LOCAL • WebR', color: 'bg-green-500/20 text-green-400 border-green-500/30' },
    cloud: { text: 'CLOUD • Docker', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30' },
    cache: { text: 'CACHE', color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' },
  };

  return (
    <div className="flex flex-col h-full bg-gray-950 text-sm select-text">

      {/* Header */}
      <div className="flex items-center justify-between px-3 py-1.5 border-b border-gray-800 bg-gray-900">
        <div className="flex items-center gap-2">
          <span className="text-gray-400 text-xs font-medium">Console R</span>
          {!webRReady && (
            <span className="text-xs text-yellow-400 animate-pulse">Iniciando motor...</span>
          )}
          {execMode && (
            <span className={`text-xs px-2 py-0.5 rounded-full border ${modeBadge[execMode]?.color}`}>
              {modeBadge[execMode]?.text}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowTimestamps(t => !t)}
            className="text-xs text-gray-500 hover:text-gray-300 transition-colors"
          >
            {showTimestamps ? 'Ocultar hora' : 'Mostrar hora'}
          </button>
          <button
            onClick={clearConsole}
            className="text-xs text-gray-500 hover:text-red-400 transition-colors"
          >
            Limpar
          </button>
        </div>
      </div>

      {/* Comandos rápidos */}
      <div className="flex gap-1 px-2 py-1 overflow-x-auto border-b border-gray-800 scrollbar-none">
        {QUICK_COMMANDS.map(cmd => (
          <button
            key={cmd.label}
            onClick={() => runCode(cmd.code)}
            disabled={isExecuting}
            className="text-xs whitespace-nowrap px-2 py-1 rounded bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-gray-200 transition-colors disabled:opacity-40"
          >
            {cmd.label}
          </button>
        ))}
      </div>

      {/* Saída do console */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-0.5 font-mono">
        <AnimatePresence initial={false}>
          {consoleLines.map((line) => (
            <motion.div
              key={line.id}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.12 }}
              className="flex items-start gap-1 leading-5"
            >
              {showTimestamps && (
                <span className="text-gray-600 text-xs shrink-0 mt-0.5 w-20">
                  {fmtTime(line.timestamp)}
                </span>
              )}
              <span className={`${LINE_STYLES[line.type]} shrink-0`}>
                {LINE_PREFIXES[line.type]}
              </span>
              <span className={`${LINE_STYLES[line.type]} break-all whitespace-pre-wrap`}
                style={{ fontSize: `${fontSize - 1}px` }}>
                {line.text}
              </span>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Spinner durante execução */}
        {isExecuting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex items-center gap-2 text-blue-400 text-xs py-1"
          >
            <span className="inline-block w-3 h-3 border-2 border-blue-400 border-t-transparent rounded-full animate-spin" />
            Executando...
            {execModeReason && <span className="text-gray-500">{execModeReason}</span>}
          </motion.div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Entrada do console */}
      <div className="border-t border-gray-800 bg-gray-900 px-3 py-2">
        <div className="flex items-center gap-2">
          <span className="text-blue-400 font-mono text-sm shrink-0">
            {isExecuting ? '⏳' : '>'}
          </span>
          <input
            ref={inputRef}
            type="text"
            value={consoleInput}
            onChange={e => setConsoleInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isExecuting}
            placeholder={webRReady ? 'Digite código R...' : 'Aguarde o motor iniciar...'}
            className={`
              flex-1 bg-transparent border-none outline-none text-gray-200 font-mono
              placeholder-gray-600 disabled:opacity-50
            `}
            style={{ fontSize: `${fontSize - 1}px` }}
            autoComplete="off"
            autoCorrect="off"
            autoCapitalize="off"
            spellCheck={false}
          />
          <button
            onClick={() => runCode(consoleInput)}
            disabled={isExecuting || !consoleInput.trim()}
            className="text-xs px-3 py-1 bg-blue-600 hover:bg-blue-500 disabled:opacity-30 text-white rounded transition-colors shrink-0"
          >
            Run
          </button>
        </div>

        {/* Dica de atalhos */}
        <div className="flex gap-3 mt-1 text-xs text-gray-600">
          <span>Enter: executar</span>
          <span>↑↓: histórico</span>
          <span>Ctrl+Enter: executar seleção no editor</span>
        </div>
      </div>
    </div>
  );
}
