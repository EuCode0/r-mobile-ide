/**
 * components/ai/AIAssistant.tsx
 * IA interna integrada ao editor:
 * - Botão "Executar com IA": analisa, roda, corrige e comenta
 * - Chat para perguntas sobre R, estatística, gráficos
 * - Correção automática de erros
 * - Geração de código R completo
 * Usa a API Anthropic (Claude) via backend seguro.
 */

'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import axios from 'axios';
import { useIDEStore } from '../../store/ide-store';
import { executeR } from '../../lib/hybrid-executor';

// ---- Prompt do sistema para IA ---------------------------------------------

const AI_SYSTEM_PROMPT = `Você é um especialista em R, estatística e ciência de dados integrado a um IDE mobile.
Responda sempre em português brasileiro.
Seja conciso e prático. Use exemplos de código R quando pertinente.
Ao corrigir erros, explique o problema e forneça o código corrigido completo.
Ao gerar gráficos, prefira ggplot2 quando disponível.
Formate código R em blocos de código markdown (\`\`\`r ... \`\`\`).
Ao otimizar código, explique o que foi melhorado e por quê.`;

// ---- Tipos -----------------------------------------------------------------

type Action = 'explain' | 'fix' | 'optimize' | 'generate' | 'convert' | 'chat';

type ActionConfig = {
  label: string;
  icon: string;
  prompt: (code: string, error?: string) => string;
  color: string;
};

const ACTIONS: Record<Action, ActionConfig> = {
  explain: {
    label: 'Explicar',
    icon: '?',
    color: 'text-blue-400 border-blue-500/30 hover:bg-blue-500/10',
    prompt: (code) =>
      `Explique este código R de forma clara e didática, linha por linha:\n\`\`\`r\n${code}\n\`\`\``,
  },
  fix: {
    label: 'Corrigir',
    icon: '✗',
    color: 'text-red-400 border-red-500/30 hover:bg-red-500/10',
    prompt: (code, error) =>
      `O seguinte código R produziu um erro. Corrija-o e explique o que estava errado:\n\nCódigo:\n\`\`\`r\n${code}\n\`\`\`\n\nErro:\n${error || 'Erro desconhecido'}`,
  },
  optimize: {
    label: 'Otimizar',
    icon: '⚡',
    color: 'text-yellow-400 border-yellow-500/30 hover:bg-yellow-500/10',
    prompt: (code) =>
      `Otimize este código R para melhor performance e legibilidade. Mostre o código melhorado e explique cada mudança:\n\`\`\`r\n${code}\n\`\`\``,
  },
  generate: {
    label: 'Gerar gráfico',
    icon: '📊',
    color: 'text-green-400 border-green-500/30 hover:bg-green-500/10',
    prompt: (code) =>
      `Com base neste código R e nos dados disponíveis, gere código para criar um gráfico informativo e bonito com ggplot2:\n\`\`\`r\n${code}\n\`\`\``,
  },
  convert: {
    label: 'Converter Python→R',
    icon: '↔',
    color: 'text-purple-400 border-purple-500/30 hover:bg-purple-500/10',
    prompt: (code) =>
      `Converta este código Python para R idiomático. Se for código pandas/numpy, use dplyr/tidyr quando apropriado:\n\`\`\`python\n${code}\n\`\`\``,
  },
  chat: {
    label: 'Chat',
    icon: '💬',
    color: 'text-cyan-400 border-cyan-500/30 hover:bg-cyan-500/10',
    prompt: (_, error) => error || '',
  },
};

// ---- Extrai blocos de código da resposta da IA ----------------------------

function extractCodeBlocks(text: string): string[] {
  const matches = [...text.matchAll(/```(?:r|R)?\n([\s\S]*?)```/g)];
  return matches.map(m => m[1].trim());
}

// ---- Componente principal --------------------------------------------------

export function AIAssistant() {
  const { aiMessages, aiVisible, activeFileId, files, consoleLines,
    addAIMessage, setAIVisible, updateFileContent, addConsoleLine,
    sessionId, setExecuting } = useIDEStore();

  const [loading, setLoading] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [runningWithAI, setRunningWithAI] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeFile = files.find(f => f.id === activeFileId);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [aiMessages]);

  // Chama a IA via backend
  const callAI = async (prompt: string): Promise<string> => {
    const API = process.env.NEXT_PUBLIC_API_URL || '/api';
    const history = aiMessages.slice(-10).map(m => ({
      role: m.role,
      content: m.content,
    }));

    const { data } = await axios.post(`${API}/ai/chat`, {
      system: AI_SYSTEM_PROMPT,
      messages: [...history, { role: 'user', content: prompt }],
    });

    return data.content;
  };

  // Executa uma ação da IA
  const runAction = async (action: Action) => {
    if (loading) return;
    const code = activeFile?.content || '';
    const lastError = consoleLines.filter(l => l.type === 'error').slice(-1)[0]?.text;

    const cfg = ACTIONS[action];
    const prompt = cfg.prompt(code, lastError);
    if (!prompt) return;

    addAIMessage('user', action === 'chat' ? chatInput : `[${cfg.label}] código atual`);
    setLoading(true);

    try {
      const response = await callAI(prompt);
      addAIMessage('assistant', response);
    } catch (err: any) {
      addAIMessage('assistant', `❌ Erro ao consultar IA: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Botão principal: Executar com IA
  const runWithAI = async () => {
    if (!activeFile || runningWithAI) return;
    setRunningWithAI(true);

    const code = activeFile.content;
    addConsoleLine('system', '[IA] Analisando código...');
    addAIMessage('user', '[Executar com IA] Analisando, executando e otimizando');

    try {
      // 1) Análise prévia pela IA
      const analysis = await callAI(
        `Analise este código R antes de executar. Identifique possíveis erros, problemas de performance ou melhorias óbvias. Seja breve (máx 3 pontos). Código:\n\`\`\`r\n${code}\n\`\`\``
      );
      addAIMessage('assistant', `**Análise pré-execução:**\n${analysis}`);

      // 2) Executa o código
      addConsoleLine('system', '[IA] Executando código...');
      const result = await executeR(code, {
        sessionId,
        onModeDecision: (mode, reason) =>
          addConsoleLine('system', `[${mode.toUpperCase()}] ${reason}`),
      });

      // Mostra resultados no console
      result.stdout.forEach(l => l.trim() && addConsoleLine('output', l));
      result.warnings.forEach(w => addConsoleLine('warning', w));
      if (result.error) addConsoleLine('error', result.error);

      // 3) Pede comentários e sugestões pós-execução
      const postPrompt = result.error
        ? `O código falhou com erro: "${result.error}". Forneça o código corrigido completo e explique o problema:`
        : `O código executou com sucesso. Output:\n${result.stdout.join('\n').slice(0, 500)}\n\nComente os resultados e sugira próximos passos ou melhorias:`;

      const postAnalysis = await callAI(`Código executado:\n\`\`\`r\n${code}\n\`\`\`\n\n${postPrompt}`);
      addAIMessage('assistant', postAnalysis);

      // Se tem código corrigido na resposta, oferece aplicar
      const fixedCode = extractCodeBlocks(postAnalysis);
      if (fixedCode.length > 0 && result.error && activeFileId) {
        addAIMessage('assistant', `_Código corrigido disponível. Deseja aplicar? Clique no botão "Aplicar correção" abaixo._`);
      }

    } catch (err: any) {
      addAIMessage('assistant', `❌ Erro: ${err.message}`);
    } finally {
      setRunningWithAI(false);
    }
  };

  // Aplica código gerado pela IA no editor
  const applyCode = (code: string) => {
    if (activeFileId) {
      updateFileContent(activeFileId, code);
      addConsoleLine('system', '[IA] Código aplicado no editor');
    }
  };

  // Formata mensagem com markdown simples
  const renderMessage = (content: string) => {
    const parts = content.split(/(```(?:r|R)?\n[\s\S]*?```)/g);
    return parts.map((part, i) => {
      const codeMatch = part.match(/```(?:r|R)?\n([\s\S]*?)```/);
      if (codeMatch) {
        const code = codeMatch[1];
        return (
          <div key={i} className="relative mt-2 mb-2 rounded-lg bg-gray-900 border border-gray-700 overflow-hidden">
            <div className="flex items-center justify-between px-3 py-1 border-b border-gray-700 bg-gray-800">
              <span className="text-xs text-gray-400">R</span>
              <div className="flex gap-2">
                <button
                  onClick={() => applyCode(code)}
                  className="text-xs text-green-400 hover:text-green-300"
                >
                  Aplicar
                </button>
                <button
                  onClick={() => navigator.clipboard.writeText(code)}
                  className="text-xs text-gray-400 hover:text-gray-200"
                >
                  Copiar
                </button>
              </div>
            </div>
            <pre className="text-xs text-gray-200 p-3 overflow-x-auto font-mono leading-5">{code}</pre>
          </div>
        );
      }
      // Formata **bold** simples
      return (
        <p key={i} className="text-sm text-gray-300 leading-relaxed whitespace-pre-wrap"
          dangerouslySetInnerHTML={{ __html: part.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }}
        />
      );
    });
  };

  if (!aiVisible) {
    return (
      <button
        onClick={() => setAIVisible(true)}
        className="fixed bottom-20 right-4 z-50 bg-purple-600 hover:bg-purple-500 text-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg transition-all"
        title="Abrir IA"
      >
        <span className="text-lg">✦</span>
      </button>
    );
  }

  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="flex flex-col h-full bg-gray-950 border-l border-gray-800"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-gray-800 bg-gray-900">
        <div className="flex items-center gap-2">
          <span className="text-purple-400 text-base">✦</span>
          <span className="text-sm font-medium text-gray-200">Assistente R com IA</span>
        </div>
        <button onClick={() => setAIVisible(false)} className="text-gray-500 hover:text-gray-300 text-sm">
          ✕
        </button>
      </div>

      {/* Botão Executar com IA (destaque) */}
      <div className="px-3 py-2 border-b border-gray-800">
        <button
          onClick={runWithAI}
          disabled={runningWithAI || !activeFile}
          className={`
            w-full py-2 rounded-lg font-medium text-sm transition-all
            ${runningWithAI
              ? 'bg-purple-800 text-purple-300 cursor-wait'
              : 'bg-purple-600 hover:bg-purple-500 text-white active:scale-95'}
            disabled:opacity-40
          `}
        >
          {runningWithAI
            ? '⏳ IA analisando e executando...'
            : '▶ Executar com IA — analisa, roda e comenta'}
        </button>

        {/* Ações rápidas */}
        <div className="grid grid-cols-3 gap-1 mt-2">
          {(Object.entries(ACTIONS) as [Action, ActionConfig][])
            .filter(([a]) => a !== 'chat')
            .map(([action, cfg]) => (
              <button
                key={action}
                onClick={() => runAction(action)}
                disabled={loading}
                className={`
                  text-xs py-1.5 px-2 rounded border transition-colors
                  ${cfg.color} disabled:opacity-30
                `}
              >
                {cfg.label}
              </button>
            ))}
        </div>
      </div>

      {/* Mensagens */}
      <div className="flex-1 overflow-y-auto px-3 py-3 space-y-3">
        {aiMessages.length === 0 && (
          <div className="text-center text-gray-600 text-sm py-8">
            <span className="text-3xl block mb-3">✦</span>
            Clique em "Executar com IA" para analisar seu código,<br />
            ou use os botões acima para ações específicas.
          </div>
        )}

        <AnimatePresence initial={false}>
          {aiMessages.map(msg => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'assistant' && (
                <div className="w-6 h-6 rounded-full bg-purple-600 flex items-center justify-center text-xs shrink-0 mt-0.5">
                  ✦
                </div>
              )}
              <div
                className={`
                  max-w-[85%] rounded-xl px-3 py-2
                  ${msg.role === 'user'
                    ? 'bg-blue-600/20 border border-blue-500/30 text-blue-100'
                    : 'bg-gray-800 border border-gray-700 text-gray-200'}
                `}
              >
                {msg.role === 'assistant'
                  ? renderMessage(msg.content)
                  : <p className="text-sm">{msg.content}</p>
                }
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {loading && (
          <div className="flex items-center gap-2 text-purple-400 text-sm">
            <span className="inline-block w-4 h-4 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
            IA processando...
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Input do chat */}
      <div className="border-t border-gray-800 bg-gray-900 px-3 py-2">
        <div className="flex gap-2">
          <input
            type="text"
            value={chatInput}
            onChange={e => setChatInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && chatInput.trim()) {
                addAIMessage('user', chatInput);
                callAI(chatInput).then(r => addAIMessage('assistant', r)).catch(() => {});
                setChatInput('');
              }
            }}
            placeholder="Pergunte sobre R, estatística, gráficos..."
            className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-3 py-2 text-sm text-gray-200 placeholder-gray-600 outline-none focus:border-purple-500 transition-colors"
          />
          <button
            onClick={() => {
              if (chatInput.trim()) {
                addAIMessage('user', chatInput);
                callAI(chatInput).then(r => addAIMessage('assistant', r)).catch(() => {});
                setChatInput('');
              }
            }}
            disabled={!chatInput.trim() || loading}
            className="px-3 py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-30 text-white rounded-lg text-sm transition-colors"
          >
            ↑
          </button>
        </div>
      </div>
    </motion.div>
  );
}
