/**
 * components/editor/REditor.tsx
 * Monaco Editor com syntax highlighting para R, autocomplete via IA,
 * breakpoints por toque, snippets e suporte mobile (zoom por gesto).
 */

'use client';

import { useRef, useEffect, useCallback } from 'react';
import Editor, { type Monaco, type OnMount } from '@monaco-editor/react';
import type * as monaco from 'monaco-editor';
import { useIDEStore } from '../../store/ide-store';
import { webREngine } from '../../lib/webr-engine';

// ---- Definição da linguagem R para Monaco ----------------------------------

function registerRLanguage(monaco: Monaco) {
  // Evita re-registro
  if (monaco.languages.getLanguages().find(l => l.id === 'r')) return;

  monaco.languages.register({ id: 'r', extensions: ['.R', '.r', '.Rmd'] });

  monaco.languages.setMonarchTokensProvider('r', {
    keywords: [
      'if','else','repeat','while','function','for','in','next','break',
      'TRUE','FALSE','NULL','Inf','NaN','NA','NA_integer_','NA_real_',
      'NA_complex_','NA_character_','...','..1','..2',
    ],
    builtins: [
      'c','list','vector','matrix','array','data.frame','factor','table',
      'sum','mean','median','sd','var','cor','cov','min','max','range',
      'length','nrow','ncol','dim','names','colnames','rownames',
      'print','cat','paste','paste0','sprintf','format','formatC',
      'plot','ggplot','hist','boxplot','barplot','pie',
      'read.csv','write.csv','read.table','readRDS','saveRDS',
      'lm','glm','t.test','chisq.test','aov','summary','predict',
      'apply','lapply','sapply','vapply','tapply','mapply','Map',
      'library','require','install.packages','installed.packages',
      'which','match','grep','grepl','sub','gsub','regexpr',
      'is.na','is.null','is.numeric','is.character','is.logical',
      'as.numeric','as.character','as.integer','as.factor','as.Date',
      'Sys.time','proc.time','system.time','date',
      'setwd','getwd','dir','list.files','file.exists',
    ],
    tokenizer: {
      root: [
        [/#.*$/, 'comment'],
        [/"([^"\\]|\\.)*"/, 'string'],
        [/'([^'\\]|\\.)*'/, 'string'],
        [/`[^`]*`/, 'variable'],
        [/\b\d+\.?\d*([eE][+-]?\d+)?\b/, 'number'],
        [/\b\d+L\b/, 'number'],
        [/\b(TRUE|FALSE|NULL|NA|Inf|NaN)\b/, 'constant'],
        [/<-|->|=|<<-|->>|\|\||&&|!|==|!=|<=|>=|<|>/, 'operator'],
        [/[+\-*\/^%%&|~]/, 'operator'],
        [/\$|@|\[|\]|\(|\)|\{|\}|,|;/, 'delimiter'],
        [new RegExp(`\\b(${['if','else','while','for','function','return','repeat','break','next','in'].join('|')})\\b`), 'keyword'],
        [/\b[a-zA-Z_][a-zA-Z0-9._]*(?=\s*\()/, 'function'],
        [/\b[a-zA-Z_][a-zA-Z0-9._]*/, 'identifier'],
      ],
    },
  });

  monaco.languages.setLanguageConfiguration('r', {
    comments: { lineComment: '#' },
    brackets: [['(', ')'], ['{', '}'], ['[', ']']],
    autoClosingPairs: [
      { open: '(', close: ')' },
      { open: '{', close: '}' },
      { open: '[', close: ']' },
      { open: '"', close: '"' },
      { open: "'", close: "'" },
    ],
    surroundingPairs: [
      { open: '(', close: ')' },
      { open: '{', close: '}' },
      { open: '[', close: ']' },
      { open: '"', close: '"' },
      { open: "'", close: "'" },
    ],
    indentationRules: {
      increaseIndentPattern: /\{[^}]*$|\([^)]*$/,
      decreaseIndentPattern: /^\s*[}\)]/,
    },
    wordPattern: /[a-zA-Z_][a-zA-Z0-9._]*/,
  });
}

// ---- Snippets R ------------------------------------------------------------

const R_SNIPPETS: monaco.languages.CompletionItem[] = [
  {
    label: 'ggplot',
    kind: 15, // Snippet
    insertText: `ggplot(\${1:data}, aes(x = \${2:x}, y = \${3:y})) +
  geom_\${4:point}() +
  labs(title = "\${5:Título}", x = "\${6:Eixo X}", y = "\${7:Eixo Y}") +
  theme_minimal()`,
    insertTextRules: 4,
    documentation: 'Gráfico ggplot2 básico',
    range: undefined as any,
  },
  {
    label: 'lm-summary',
    kind: 15,
    insertText: `modelo <- lm(\${1:y} ~ \${2:x}, data = \${3:df})
summary(modelo)
plot(modelo)`,
    insertTextRules: 4,
    documentation: 'Regressão linear com diagnóstico',
    range: undefined as any,
  },
  {
    label: 'read-csv',
    kind: 15,
    insertText: `\${1:df} <- read.csv("\${2:arquivo.csv}",
  header = TRUE,
  sep = ",",
  stringsAsFactors = FALSE,
  encoding = "UTF-8"
)
head(\${1:df})
str(\${1:df})`,
    insertTextRules: 4,
    documentation: 'Importar CSV com diagnóstico',
    range: undefined as any,
  },
  {
    label: 'function',
    kind: 15,
    insertText: `\${1:nome_funcao} <- function(\${2:args}) {
  \${3:# corpo}
  return(\${4:resultado})
}`,
    insertTextRules: 4,
    documentation: 'Definir função R',
    range: undefined as any,
  },
  {
    label: 'for-loop',
    kind: 15,
    insertText: `for (\${1:i} in \${2:1:10}) {
  \${3:# corpo}
}`,
    insertTextRules: 4,
    documentation: 'Loop for',
    range: undefined as any,
  },
  {
    label: 'tryCatch',
    kind: 15,
    insertText: `tryCatch({
  \${1:# código}
}, error = function(e) {
  cat("Erro:", conditionMessage(e), "\\n")
}, warning = function(w) {
  cat("Aviso:", conditionMessage(w), "\\n")
})`,
    insertTextRules: 4,
    documentation: 'Tratamento de erros',
    range: undefined as any,
  },
];

// ---- Provedor de autocomplete ----------------------------------------------

function registerCompletionProvider(monaco: Monaco) {
  monaco.languages.registerCompletionItemProvider('r', {
    triggerCharacters: ['$', '@', '::', '.', ' '],
    async provideCompletionItems(model, position) {
      const word = model.getWordUntilPosition(position);
      const range = {
        startLineNumber: position.lineNumber,
        endLineNumber: position.lineNumber,
        startColumn: word.startColumn,
        endColumn: word.endColumn,
      };

      // Autocomplete do WebR (funções disponíveis no ambiente)
      let webRCompletions: monaco.languages.CompletionItem[] = [];
      if (webREngine.ready) {
        const prefix = model.getValueInRange({
          startLineNumber: position.lineNumber,
          startColumn: 1,
          endLineNumber: position.lineNumber,
          endColumn: position.column,
        });
        try {
          const completions = await webREngine.getCompletions(prefix);
          webRCompletions = completions.map(c => ({
            label: c,
            kind: monaco.languages.CompletionItemKind.Function,
            insertText: c,
            range,
          }));
        } catch {}
      }

      const snippets = R_SNIPPETS.map(s => ({ ...s, range }));

      return {
        suggestions: [...snippets, ...webRCompletions],
        incomplete: false,
      };
    },
  });
}

// ---- Componente ------------------------------------------------------------

type Props = {
  fileId: string;
  onRunSelection?: (code: string) => void;
};

export function REditor({ fileId, onRunSelection }: Props) {
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  const monacoRef = useRef<Monaco | null>(null);
  const decorationsRef = useRef<string[]>([]);

  const { files, breakpoints, currentDebugLine, theme, fontSize,
    updateFileContent, toggleBreakpoint, saveFile } = useIDEStore();

  const file = files.find(f => f.id === fileId);

  // Atualiza decorações de breakpoints e linha de debug
  const updateDecorations = useCallback(() => {
    const editor = editorRef.current;
    if (!editor) return;

    const newDecs: monaco.editor.IModelDeltaDecoration[] = [];

    // Breakpoints (vermelho)
    breakpoints
      .filter(b => b.fileId === fileId)
      .forEach(b => {
        newDecs.push({
          range: { startLineNumber: b.line, startColumn: 1, endLineNumber: b.line, endColumn: 1 },
          options: {
            isWholeLine: true,
            className: 'r-breakpoint-line',
            glyphMarginClassName: 'r-breakpoint-glyph',
            glyphMarginHoverMessage: { value: 'Breakpoint — clique para remover' },
          },
        });
      });

    // Linha atual de debug (amarelo)
    if (currentDebugLine !== null) {
      newDecs.push({
        range: {
          startLineNumber: currentDebugLine,
          startColumn: 1,
          endLineNumber: currentDebugLine,
          endColumn: 1,
        },
        options: {
          isWholeLine: true,
          className: 'r-debug-current-line',
          glyphMarginClassName: 'r-debug-current-glyph',
        },
      });
    }

    decorationsRef.current = editor.deltaDecorations(decorationsRef.current, newDecs);
  }, [fileId, breakpoints, currentDebugLine]);

  const handleEditorMount: OnMount = useCallback((editor, monaco) => {
    editorRef.current = editor;
    monacoRef.current = monaco;

    registerRLanguage(monaco);
    registerCompletionProvider(monaco);

    // Salvar com Ctrl+S / Cmd+S
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
      saveFile(fileId);
    });

    // Executar seleção com Ctrl+Enter
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter, () => {
      const selection = editor.getSelection();
      if (!selection) return;
      const model = editor.getModel();
      if (!model) return;
      const code = selection.isEmpty()
        ? model.getLineContent(selection.startLineNumber)
        : model.getValueInRange(selection);
      onRunSelection?.(code);
    });

    // Breakpoints ao clicar na margem
    editor.onMouseDown(e => {
      if (e.target.type === monaco.editor.MouseTargetType.GUTTER_GLYPH_MARGIN ||
          e.target.type === monaco.editor.MouseTargetType.GUTTER_LINE_NUMBERS) {
        const line = e.target.position?.lineNumber;
        if (line) toggleBreakpoint(fileId, line);
      }
    });

    // Configuração mobile: desativa recursos pesados em telas pequenas
    if (window.innerWidth < 768) {
      editor.updateOptions({
        minimap: { enabled: false },
        scrollbar: { vertical: 'auto', horizontal: 'auto' },
        wordWrap: 'on',
        lineNumbersMinChars: 3,
      });
    }

    updateDecorations();
  }, [fileId, onRunSelection, toggleBreakpoint, saveFile, updateDecorations]);

  // Sincroniza decorações quando breakpoints mudam
  useEffect(() => {
    updateDecorations();
  }, [updateDecorations]);

  if (!file) return <div className="flex-1 flex items-center justify-center text-gray-500">Nenhum arquivo aberto</div>;

  return (
    <div className="flex-1 relative overflow-hidden">
      {/* Indicador de arquivo modificado */}
      {file.modified && (
        <div className="absolute top-2 right-4 z-10 text-xs text-yellow-400 bg-yellow-400/10 px-2 py-1 rounded">
          ● não salvo
        </div>
      )}

      <Editor
        height="100%"
        language="r"
        value={file.content}
        theme={theme === 'dark' ? 'vs-dark' : 'vs'}
        options={{
          fontSize,
          fontFamily: "'JetBrains Mono', 'Fira Code', monospace",
          fontLigatures: true,
          lineNumbers: 'on',
          glyphMargin: true,
          folding: true,
          minimap: { enabled: true, maxColumn: 80 },
          scrollBeyondLastLine: false,
          automaticLayout: true,
          tabSize: 2,
          insertSpaces: true,
          wordWrap: 'on',
          suggestOnTriggerCharacters: true,
          quickSuggestions: { other: true, comments: false, strings: false },
          parameterHints: { enabled: true },
          formatOnPaste: true,
          renderWhitespace: 'boundary',
          smoothScrolling: true,
          cursorSmoothCaretAnimation: 'on',
          bracketPairColorization: { enabled: true },
          guides: { bracketPairs: true },
          // Mobile touch
          mouseWheelZoom: true,
          pinchZoom: true,
        }}
        onChange={(value) => updateFileContent(fileId, value || '')}
        onMount={handleEditorMount}
      />

      <style>{`
        .r-breakpoint-line { background: rgba(255, 80, 80, 0.12) !important; }
        .r-breakpoint-glyph { background: #ff5050; border-radius: 50%; margin-left: 4px; width: 10px !important; height: 10px !important; margin-top: 4px; }
        .r-debug-current-line { background: rgba(255, 220, 0, 0.18) !important; }
        .r-debug-current-glyph { border-left: 3px solid #ffdc00; }
      `}</style>
    </div>
  );
}
