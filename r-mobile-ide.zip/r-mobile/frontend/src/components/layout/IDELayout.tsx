/**
 * components/layout/IDELayout.tsx
 * Layout principal da IDE com painéis redimensionáveis.
 * Mobile: abas deslizantes. Desktop: painel dividido.
 */

'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import { useIDEStore } from '../../store/ide-store';
import { REditor } from '../editor/REditor';
import { RConsole } from '../console/RConsole';
import { AIAssistant } from '../ai/AIAssistant';
import { executeR } from '../../lib/hybrid-executor';
import { webREngine } from '../../lib/webr-engine';

// ---- Abas mobile -----------------------------------------------------------

type Tab = 'editor' | 'console' | 'plots' | 'env' | 'files';

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: 'editor',  label: 'Editor',   icon: '{ }' },
  { id: 'console', label: 'Console',  icon: '>' },
  { id: 'plots',   label: 'Gráficos', icon: '📊' },
  { id: 'env',     label: 'Variáveis',icon: '≡' },
  { id: 'files',   label: 'Arquivos', icon: '📁' },
];

// ---- Barra de ferramentas --------------------------------------------------

function Toolbar({ onRun, onRunWithAI, isExecuting }: {
  onRun: () => void;
  onRunWithAI: () => void;
  isExecuting: boolean;
}) {
  const { activeFileId, files, theme, setTheme, fontSize, setFontSize,
    createFile, webRReady, setAIVisible, aiVisible } = useIDEStore();
  const activeFile = files.find(f => f.id === activeFileId);

  return (
    <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-900 border-b border-gray-800">
      {/* Logo */}
      <div className="flex items-center gap-1.5 mr-2">
        <div className="w-5 h-5 rounded bg-blue-600 flex items-center justify-center">
          <span className="text-white text-xs font-bold">R</span>
        </div>
        <span className="text-xs text-gray-400 font-medium hidden sm:block">R Mobile IDE</span>
      </div>

      {/* Botão Executar */}
      <button
        onClick={onRun}
        disabled={isExecuting || !activeFile || !webRReady}
        className="flex items-center gap-1.5 px-3 py-1 bg-green-600 hover:bg-green-500 disabled:opacity-40 text-white text-xs rounded-md transition-colors font-medium"
      >
        {isExecuting
          ? <span className="inline-block w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
          : '▶'
        }
        <span className="hidden sm:inline">Executar</span>
      </button>

      {/* Executar com IA */}
      <button
        onClick={onRunWithAI}
        disabled={isExecuting || !activeFile}
        className="flex items-center gap-1.5 px-3 py-1 bg-purple-600 hover:bg-purple-500 disabled:opacity-40 text-white text-xs rounded-md transition-colors font-medium"
      >
        ✦ <span className="hidden sm:inline">IA</span>
      </button>

      {/* Novo arquivo */}
      <button
        onClick={() => createFile(`script_${Date.now()}.R`)}
        className="px-2 py-1 text-xs text-gray-400 hover:text-gray-200 hover:bg-gray-800 rounded transition-colors"
        title="Novo arquivo"
      >
        +
      </button>

      <div className="flex-1" />

      {/* Status WebR */}
      <div className={`text-xs px-2 py-0.5 rounded-full ${
        webRReady
          ? 'bg-green-500/20 text-green-400'
          : 'bg-yellow-500/20 text-yellow-400 animate-pulse'
      }`}>
        {webRReady ? 'R ativo' : 'Iniciando...'}
      </div>

      {/* Tamanho da fonte */}
      <div className="flex items-center gap-1">
        <button onClick={() => setFontSize(Math.max(10, fontSize - 1))}
          className="text-xs text-gray-500 hover:text-gray-300 w-5 h-5 flex items-center justify-center">
          A-
        </button>
        <span className="text-xs text-gray-500 w-4 text-center">{fontSize}</span>
        <button onClick={() => setFontSize(Math.min(24, fontSize + 1))}
          className="text-xs text-gray-500 hover:text-gray-300 w-5 h-5 flex items-center justify-center">
          A+
        </button>
      </div>

      {/* Tema */}
      <button
        onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        className="text-xs text-gray-500 hover:text-gray-300 px-2 py-1 rounded hover:bg-gray-800 transition-colors"
      >
        {theme === 'dark' ? '☀' : '🌙'}
      </button>
    </div>
  );
}

// ---- Abas de arquivos abertos ----------------------------------------------

function FileTabs() {
  const { files, openFileIds, activeFileId, openFile, closeFile } = useIDEStore();

  if (openFileIds.length === 0) return null;

  return (
    <div className="flex overflow-x-auto border-b border-gray-800 bg-gray-900 scrollbar-none">
      {openFileIds.map(id => {
        const file = files.find(f => f.id === id);
        if (!file) return null;
        return (
          <button
            key={id}
            onClick={() => openFile(id)}
            className={`
              flex items-center gap-2 px-3 py-1.5 text-xs border-r border-gray-800 whitespace-nowrap
              transition-colors group shrink-0
              ${activeFileId === id
                ? 'bg-gray-800 text-gray-200 border-b-2 border-b-blue-500'
                : 'text-gray-500 hover:text-gray-300 hover:bg-gray-850'}
            `}
          >
            <span className="text-gray-500">{file.name.endsWith('.R') ? '{ }' : '📄'}</span>
            {file.name}
            {file.modified && <span className="text-yellow-400 text-xs">●</span>}
            <span
              onClick={(e) => { e.stopPropagation(); closeFile(id); }}
              className="opacity-0 group-hover:opacity-100 text-gray-600 hover:text-gray-200 ml-1 transition-opacity"
            >
              ✕
            </span>
          </button>
        );
      })}
    </div>
  );
}

// ---- Painel de variáveis ---------------------------------------------------

function EnvPanel() {
  const { envVars } = useIDEStore();

  return (
    <div className="flex-1 overflow-y-auto bg-gray-950 p-2">
      {envVars.length === 0
        ? <p className="text-center text-gray-600 text-sm py-8">Nenhuma variável no ambiente</p>
        : (
          <table className="w-full text-xs font-mono">
            <thead>
              <tr className="text-gray-500 border-b border-gray-800">
                <th className="text-left py-1 px-2">Nome</th>
                <th className="text-left py-1 px-2">Tipo</th>
                <th className="text-left py-1 px-2">Preview</th>
              </tr>
            </thead>
            <tbody>
              {envVars.map(v => (
                <tr key={v.name} className="border-b border-gray-900 hover:bg-gray-900 transition-colors">
                  <td className="py-1.5 px-2 text-blue-400 font-medium">{v.name}</td>
                  <td className="py-1.5 px-2 text-yellow-500">{v.type}</td>
                  <td className="py-1.5 px-2 text-gray-400 truncate max-w-xs">{v.preview}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )
      }
    </div>
  );
}

// ---- Painel de gráficos ----------------------------------------------------

function PlotsPanel() {
  const { plots, activePlotId, setActivePlot, removePlot } = useIDEStore();
  const active = plots.find(p => p.id === activePlotId) ?? plots[plots.length - 1];

  return (
    <div className="flex flex-col h-full bg-gray-950">
      {/* Miniaturas */}
      {plots.length > 1 && (
        <div className="flex gap-2 p-2 overflow-x-auto border-b border-gray-800">
          {plots.map(p => (
            <button
              key={p.id}
              onClick={() => setActivePlot(p.id)}
              className={`
                shrink-0 w-16 h-12 rounded overflow-hidden border transition-colors
                ${p.id === activePlotId ? 'border-blue-500' : 'border-gray-700 hover:border-gray-500'}
              `}
              dangerouslySetInnerHTML={{ __html: p.svg }}
            />
          ))}
        </div>
      )}

      {/* Plot ativo */}
      <div className="flex-1 flex items-center justify-center p-4 overflow-auto">
        {active
          ? (
            <div className="relative max-w-full">
              <div
                dangerouslySetInnerHTML={{ __html: active.svg }}
                className="w-full rounded-lg overflow-hidden"
              />
              <div className="flex gap-2 mt-2 justify-end">
                <button
                  onClick={() => {
                    const blob = new Blob([active.svg], { type: 'image/svg+xml' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url; a.download = `plot_${Date.now()}.svg`; a.click();
                  }}
                  className="text-xs text-gray-400 hover:text-gray-200 px-2 py-1 rounded bg-gray-800 transition-colors"
                >
                  ↓ SVG
                </button>
                <button
                  onClick={() => removePlot(active.id)}
                  className="text-xs text-red-500 hover:text-red-300 px-2 py-1 rounded bg-gray-800 transition-colors"
                >
                  Remover
                </button>
              </div>
            </div>
          )
          : <p className="text-center text-gray-600 text-sm">Nenhum gráfico gerado ainda</p>
        }
      </div>
    </div>
  );
}

// ---- Layout principal ------------------------------------------------------

export function IDELayout() {
  const [activeTab, setActiveTab] = useState<Tab>('editor');
  const [isMobile, setIsMobile] = useState(false);

  const { activeFileId, files, isExecuting, sessionId,
    addConsoleLine, addPlot, setEnvVars,
    setExecuting, createFile, setWebRReady, setWebRProgress } = useIDEStore();

  const activeFile = files.find(f => f.id === activeFileId);

  // Detecta mobile
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  // Inicializa WebR
  useEffect(() => {
    webREngine.init((msg) => {
      setWebRProgress(msg);
      if (msg.includes('pronto')) setWebRReady(true);
    }).catch(e => addConsoleLine('error', `Erro ao iniciar WebR: ${e.message}`));
  }, []);

  // Cria arquivo inicial
  useEffect(() => {
    if (files.length === 0) createFile('main.R');
  }, []);

  // Executa arquivo ativo
  const handleRun = async () => {
    if (!activeFile || isExecuting) return;
    setExecuting(true);
    addConsoleLine('input', `# Executando: ${activeFile.name}`);
    setActiveTab('console');

    const result = await executeR(activeFile.content, {
      sessionId,
      onModeDecision: (mode, reason) => {
        setExecuting(true, mode, reason);
        addConsoleLine('system', `[${mode.toUpperCase()}] ${reason}`);
      },
    });

    result.stdout.forEach(l => l.trim() && addConsoleLine('output', l));
    result.warnings.forEach(w => addConsoleLine('warning', w));
    if (result.error) addConsoleLine('error', result.error);
    result.plots.forEach(svg => { addPlot(svg, activeFile.content); setActiveTab('plots'); });

    if (webREngine.ready) {
      setEnvVars(await webREngine.getEnvironmentVars());
    }

    addConsoleLine('system', `Concluído em ${result.duration}ms`);
    setExecuting(false);
  };

  const handleRunWithAI = () => {
    const { setAIVisible, aiMessages, addAIMessage } = useIDEStore.getState();
    setAIVisible(true);
    // Dispara o runWithAI via AIAssistant
    document.dispatchEvent(new CustomEvent('r-mobile:run-with-ai'));
  };

  // ---- Layout Mobile --------------------------------------------------------

  if (isMobile) {
    return (
      <div className="flex flex-col h-screen bg-gray-950">
        <Toolbar onRun={handleRun} onRunWithAI={handleRunWithAI} isExecuting={isExecuting} />
        <FileTabs />

        {/* Conteúdo da aba */}
        <div className="flex-1 overflow-hidden relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.15 }}
              className="absolute inset-0 flex flex-col"
            >
              {activeTab === 'editor' && activeFileId && <REditor fileId={activeFileId} onRunSelection={(code) => executeR(code, { sessionId })} />}
              {activeTab === 'console' && <RConsole />}
              {activeTab === 'plots' && <PlotsPanel />}
              {activeTab === 'env' && <EnvPanel />}
              {activeTab === 'files' && (
                <div className="flex-1 p-4 text-gray-400 text-sm">
                  Gerenciador de arquivos em breve
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Barra de abas inferior */}
        <div className="flex border-t border-gray-800 bg-gray-900">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`
                flex-1 flex flex-col items-center py-1.5 gap-0.5 text-xs transition-colors
                ${activeTab === tab.id
                  ? 'text-blue-400 border-t-2 border-blue-400'
                  : 'text-gray-500 hover:text-gray-300'}
              `}
            >
              <span className="text-sm">{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* IA flutuante */}
        <AIAssistant />
      </div>
    );
  }

  // ---- Layout Desktop -------------------------------------------------------

  return (
    <div className="flex flex-col h-screen bg-gray-950">
      <Toolbar onRun={handleRun} onRunWithAI={handleRunWithAI} isExecuting={isExecuting} />
      <FileTabs />

      <div className="flex-1 overflow-hidden">
        <PanelGroup direction="horizontal">
          {/* Editor */}
          <Panel defaultSize={55} minSize={30}>
            {activeFileId
              ? <REditor fileId={activeFileId} onRunSelection={(code) => executeR(code, { sessionId })} />
              : (
                <div className="h-full flex items-center justify-center text-gray-600">
                  <div className="text-center">
                    <div className="text-5xl mb-4">{ }</div>
                    <p className="text-lg mb-2">Nenhum arquivo aberto</p>
                    <button
                      onClick={() => useIDEStore.getState().createFile('main.R')}
                      className="text-blue-400 hover:text-blue-300 text-sm underline"
                    >
                      Criar main.R
                    </button>
                  </div>
                </div>
              )
            }
          </Panel>

          <PanelResizeHandle className="w-1 bg-gray-800 hover:bg-blue-600 transition-colors cursor-col-resize" />

          {/* Painel direito */}
          <Panel defaultSize={45} minSize={25}>
            <PanelGroup direction="vertical">
              {/* Console */}
              <Panel defaultSize={55} minSize={20}>
                <RConsole />
              </Panel>

              <PanelResizeHandle className="h-1 bg-gray-800 hover:bg-blue-600 transition-colors cursor-row-resize" />

              {/* Gráficos + Variáveis */}
              <Panel defaultSize={45} minSize={20}>
                <PanelGroup direction="horizontal">
                  <Panel defaultSize={60}>
                    <PlotsPanel />
                  </Panel>
                  <PanelResizeHandle className="w-1 bg-gray-800 hover:bg-blue-600 transition-colors cursor-col-resize" />
                  <Panel defaultSize={40}>
                    <div className="flex flex-col h-full">
                      <div className="px-3 py-1.5 border-b border-gray-800 bg-gray-900">
                        <span className="text-xs text-gray-400 font-medium">Ambiente</span>
                      </div>
                      <EnvPanel />
                    </div>
                  </Panel>
                </PanelGroup>
              </Panel>
            </PanelGroup>
          </Panel>

          {/* Painel IA (quando visível) */}
          <AnimatePresence>
            {useIDEStore.getState().aiVisible && (
              <>
                <PanelResizeHandle className="w-1 bg-gray-800 hover:bg-purple-600 transition-colors cursor-col-resize" />
                <Panel defaultSize={30} minSize={20}>
                  <AIAssistant />
                </Panel>
              </>
            )}
          </AnimatePresence>
        </PanelGroup>
      </div>
    </div>
  );
}
