/**
 * store/ide-store.ts
 * Estado global da IDE usando Zustand.
 * Centraliza: arquivos abertos, console, variáveis, modo de execução, IA.
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { ExecMode } from '../lib/hybrid-executor';

// ---- Tipos -----------------------------------------------------------------

export type RFile = {
  id: string;
  name: string;
  content: string;
  language: 'r' | 'rmd' | 'csv' | 'txt';
  modified: boolean;
  createdAt: number;
  savedAt: number | null;
};

export type ConsoleLine = {
  id: string;
  type: 'input' | 'output' | 'error' | 'warning' | 'info' | 'system';
  text: string;
  timestamp: number;
};

export type EnvVar = {
  name: string;
  type: string;
  preview: string;
};

export type PlotItem = {
  id: string;
  svg: string;
  timestamp: number;
  code: string;   // código que gerou o plot
};

export type BreakPoint = {
  fileId: string;
  line: number;
};

export type AIMessage = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
};

// ---- Estado ----------------------------------------------------------------

type IDEState = {
  // Arquivos
  files: RFile[];
  activeFileId: string | null;
  openFileIds: string[];

  // Console
  consoleLines: ConsoleLine[];
  consoleInput: string;
  isExecuting: boolean;
  execMode: ExecMode | null;
  execModeReason: string;

  // Ambiente
  envVars: EnvVar[];

  // Plots
  plots: PlotItem[];
  activePlotId: string | null;

  // Debug
  breakpoints: BreakPoint[];
  currentDebugLine: number | null;
  isDebugging: boolean;

  // IA
  aiMessages: AIMessage[];
  aiVisible: boolean;

  // Configurações
  theme: 'dark' | 'light';
  fontSize: number;
  sessionId: string;
  webRReady: boolean;
  webRInitProgress: string;

  // Actions — arquivos
  createFile: (name?: string) => RFile;
  openFile: (id: string) => void;
  closeFile: (id: string) => void;
  updateFileContent: (id: string, content: string) => void;
  saveFile: (id: string) => void;
  deleteFile: (id: string) => void;
  importFile: (name: string, content: string, language?: RFile['language']) => RFile;

  // Actions — console
  addConsoleLine: (type: ConsoleLine['type'], text: string) => void;
  clearConsole: () => void;
  setConsoleInput: (v: string) => void;
  setExecuting: (v: boolean, mode?: ExecMode, reason?: string) => void;

  // Actions — ambiente
  setEnvVars: (vars: EnvVar[]) => void;

  // Actions — plots
  addPlot: (svg: string, code: string) => void;
  removePlot: (id: string) => void;
  setActivePlot: (id: string | null) => void;

  // Actions — debug
  toggleBreakpoint: (fileId: string, line: number) => void;
  setCurrentDebugLine: (line: number | null) => void;
  setDebugging: (v: boolean) => void;

  // Actions — IA
  addAIMessage: (role: AIMessage['role'], content: string) => void;
  clearAIChat: () => void;
  setAIVisible: (v: boolean) => void;

  // Actions — config
  setTheme: (t: 'dark' | 'light') => void;
  setFontSize: (n: number) => void;
  setWebRReady: (v: boolean) => void;
  setWebRProgress: (msg: string) => void;
};

// ---- Helpers ---------------------------------------------------------------

const uid = () => Math.random().toString(36).slice(2, 10);

const DEFAULT_R_CODE = `# Bem-vindo ao R Mobile IDE!
# Seu laboratório de ciência de dados no Android 📱

# Exemplo básico
x <- 1:10
y <- x^2

plot(x, y,
  main = "Exemplo: y = x²",
  xlab = "x",
  ylab = "y = x²",
  type = "b",
  col = "steelblue",
  pch = 16,
  lwd = 2
)

cat("Média de y:", mean(y), "\\n")
cat("Desvio padrão:", sd(y), "\\n")
`;

// ---- Store -----------------------------------------------------------------

export const useIDEStore = create<IDEState>()(
  persist(
    (set, get) => ({
      // Estado inicial
      files: [],
      activeFileId: null,
      openFileIds: [],
      consoleLines: [],
      consoleInput: '',
      isExecuting: false,
      execMode: null,
      execModeReason: '',
      envVars: [],
      plots: [],
      activePlotId: null,
      breakpoints: [],
      currentDebugLine: null,
      isDebugging: false,
      aiMessages: [],
      aiVisible: false,
      theme: 'dark',
      fontSize: 14,
      sessionId: uid(),
      webRReady: false,
      webRInitProgress: '',

      // ---- Arquivos --------------------------------------------------------

      createFile: (name = 'script.R') => {
        const file: RFile = {
          id: uid(),
          name,
          content: name.endsWith('.R') ? DEFAULT_R_CODE : '',
          language: name.endsWith('.Rmd') ? 'rmd' : name.endsWith('.csv') ? 'csv' : 'r',
          modified: false,
          createdAt: Date.now(),
          savedAt: null,
        };
        set(s => ({
          files: [...s.files, file],
          activeFileId: file.id,
          openFileIds: [...s.openFileIds, file.id],
        }));
        return file;
      },

      openFile: (id) => {
        set(s => ({
          activeFileId: id,
          openFileIds: s.openFileIds.includes(id) ? s.openFileIds : [...s.openFileIds, id],
        }));
      },

      closeFile: (id) => {
        set(s => {
          const remaining = s.openFileIds.filter(f => f !== id);
          const newActive =
            s.activeFileId === id
              ? remaining[remaining.length - 1] ?? null
              : s.activeFileId;
          return { openFileIds: remaining, activeFileId: newActive };
        });
      },

      updateFileContent: (id, content) => {
        set(s => ({
          files: s.files.map(f =>
            f.id === id ? { ...f, content, modified: true } : f
          ),
        }));
      },

      saveFile: (id) => {
        set(s => ({
          files: s.files.map(f =>
            f.id === id ? { ...f, modified: false, savedAt: Date.now() } : f
          ),
        }));
      },

      deleteFile: (id) => {
        const s = get();
        const remaining = s.openFileIds.filter(f => f !== id);
        set({
          files: s.files.filter(f => f.id !== id),
          openFileIds: remaining,
          activeFileId:
            s.activeFileId === id ? remaining[remaining.length - 1] ?? null : s.activeFileId,
        });
      },

      importFile: (name, content, language = 'r') => {
        const file: RFile = {
          id: uid(),
          name,
          content,
          language,
          modified: false,
          createdAt: Date.now(),
          savedAt: Date.now(),
        };
        set(s => ({
          files: [...s.files, file],
          activeFileId: file.id,
          openFileIds: [...s.openFileIds, file.id],
        }));
        return file;
      },

      // ---- Console --------------------------------------------------------

      addConsoleLine: (type, text) => {
        const line: ConsoleLine = { id: uid(), type, text, timestamp: Date.now() };
        set(s => ({
          consoleLines: [...s.consoleLines.slice(-500), line], // máx 500 linhas
        }));
      },

      clearConsole: () => set({ consoleLines: [] }),
      setConsoleInput: (v) => set({ consoleInput: v }),

      setExecuting: (v, mode, reason) =>
        set({ isExecuting: v, execMode: mode ?? null, execModeReason: reason ?? '' }),

      // ---- Ambiente -------------------------------------------------------

      setEnvVars: (vars) => set({ envVars: vars }),

      // ---- Plots ----------------------------------------------------------

      addPlot: (svg, code) => {
        const plot: PlotItem = { id: uid(), svg, timestamp: Date.now(), code };
        set(s => ({ plots: [...s.plots, plot], activePlotId: plot.id }));
      },

      removePlot: (id) =>
        set(s => ({ plots: s.plots.filter(p => p.id !== id) })),

      setActivePlot: (id) => set({ activePlotId: id }),

      // ---- Debug ----------------------------------------------------------

      toggleBreakpoint: (fileId, line) => {
        set(s => {
          const exists = s.breakpoints.some(b => b.fileId === fileId && b.line === line);
          return {
            breakpoints: exists
              ? s.breakpoints.filter(b => !(b.fileId === fileId && b.line === line))
              : [...s.breakpoints, { fileId, line }],
          };
        });
      },

      setCurrentDebugLine: (line) => set({ currentDebugLine: line }),
      setDebugging: (v) => set({ isDebugging: v }),

      // ---- IA -------------------------------------------------------------

      addAIMessage: (role, content) => {
        const msg: AIMessage = { id: uid(), role, content, timestamp: Date.now() };
        set(s => ({ aiMessages: [...s.aiMessages, msg] }));
      },

      clearAIChat: () => set({ aiMessages: [] }),
      setAIVisible: (v) => set({ aiVisible: v }),

      // ---- Config ---------------------------------------------------------

      setTheme: (t) => set({ theme: t }),
      setFontSize: (n) => set({ fontSize: n }),
      setWebRReady: (v) => set({ webRReady: v }),
      setWebRProgress: (msg) => set({ webRInitProgress: msg }),
    }),
    {
      name: 'r-mobile-ide-state',
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        files: s.files,
        theme: s.theme,
        fontSize: s.fontSize,
        plots: s.plots.slice(-20),    // salva últimos 20 plots
        breakpoints: s.breakpoints,
      }),
    }
  )
);
