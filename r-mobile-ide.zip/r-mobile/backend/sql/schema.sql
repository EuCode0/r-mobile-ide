-- =============================================================================
-- R Mobile IDE — Schema PostgreSQL
-- =============================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Usuários
CREATE TABLE users (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email       VARCHAR(255) UNIQUE NOT NULL,
  name        VARCHAR(255),
  plan        VARCHAR(20) DEFAULT 'free' CHECK (plan IN ('free', 'premium', 'team')),
  cloud_credits INTEGER DEFAULT 100,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  last_active TIMESTAMPTZ DEFAULT NOW()
);

-- Projetos / Workspaces
CREATE TABLE projects (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
  name        VARCHAR(255) NOT NULL,
  description TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Arquivos R
CREATE TABLE files (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id  UUID REFERENCES projects(id) ON DELETE CASCADE,
  name        VARCHAR(255) NOT NULL,
  content     TEXT DEFAULT '',
  language    VARCHAR(20) DEFAULT 'r',
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  saved_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Sessões de execução
CREATE TABLE sessions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES users(id),
  project_id      UUID REFERENCES projects(id),
  started_at      TIMESTAMPTZ DEFAULT NOW(),
  ended_at        TIMESTAMPTZ,
  exec_mode       VARCHAR(10),     -- local | cloud | cache
  total_executions INTEGER DEFAULT 0,
  total_errors     INTEGER DEFAULT 0
);

-- Log de execuções (para analytics e debug)
CREATE TABLE executions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id  UUID REFERENCES sessions(id),
  user_id     UUID REFERENCES users(id),
  code_hash   VARCHAR(64),
  exec_mode   VARCHAR(10),
  duration_ms INTEGER,
  success     BOOLEAN,
  error_msg   TEXT,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Cache de resultados (complementa Redis com persistência)
CREATE TABLE result_cache (
  code_hash   VARCHAR(64) PRIMARY KEY,
  result      JSONB NOT NULL,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  hits        INTEGER DEFAULT 0
);

-- Templates de código compartilhados
CREATE TABLE templates (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id     UUID REFERENCES users(id),
  title       VARCHAR(255) NOT NULL,
  description TEXT,
  code        TEXT NOT NULL,
  tags        TEXT[],
  public      BOOLEAN DEFAULT FALSE,
  downloads   INTEGER DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX idx_executions_user ON executions(user_id, created_at DESC);
CREATE INDEX idx_executions_session ON executions(session_id);
CREATE INDEX idx_files_project ON files(project_id);
CREATE INDEX idx_templates_public ON templates(public, downloads DESC) WHERE public = TRUE;
CREATE INDEX idx_result_cache_created ON result_cache(created_at);

-- View: estatísticas por usuário (painel admin)
CREATE VIEW user_stats AS
SELECT
  u.id,
  u.email,
  u.plan,
  COUNT(DISTINCT s.id) AS total_sessions,
  COUNT(e.id) AS total_executions,
  SUM(CASE WHEN e.success THEN 1 ELSE 0 END) AS successful_executions,
  AVG(e.duration_ms) AS avg_duration_ms,
  u.last_active
FROM users u
LEFT JOIN sessions s ON s.user_id = u.id
LEFT JOIN executions e ON e.user_id = u.id
GROUP BY u.id, u.email, u.plan, u.last_active;

-- Limpeza automática de cache antigo
CREATE OR REPLACE FUNCTION cleanup_old_cache() RETURNS void AS $$
BEGIN
  DELETE FROM result_cache WHERE created_at < NOW() - INTERVAL '24 hours';
  DELETE FROM executions WHERE created_at < NOW() - INTERVAL '30 days';
END;
$$ LANGUAGE plpgsql;
