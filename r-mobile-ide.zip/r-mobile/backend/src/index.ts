/**
 * backend/src/index.ts
 * Servidor Node.js que expõe:
 * - POST /api/execute  → executa R em container Docker isolado
 * - POST /api/ai/chat  → proxy seguro para Anthropic Claude
 * - GET  /api/health   → healthcheck
 * - Segurança: rate limiting, autenticação JWT, sandbox
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { json } from 'body-parser';
import Docker from 'dockerode';
import Anthropic from '@anthropic-ai/sdk';
import jwt from 'jsonwebtoken';
import { createClient } from 'redis';
import crypto from 'crypto';

const app = express();
const docker = new Docker({ socketPath: '/var/run/docker.sock' });
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ---- Redis para rate limiting e cache ------------------------------------

const redis = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
redis.connect().catch(console.error);

// ---- Middlewares --------------------------------------------------------

app.use(helmet({
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  credentials: true,
}));

app.use(json({ limit: '5mb' }));

// Rate limiting geral
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minuto
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || 'unknown',
  message: { error: 'Muitas requisições. Aguarde 1 minuto.' },
});
app.use('/api', limiter);

// Rate limiting para execução (mais restrito)
const execLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  message: { error: 'Limite de execuções atingido. Máx 20/min por IP.' },
});

// ---- Autenticação JWT (opcional) ----------------------------------------

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-in-production';

function optionalAuth(req: any, res: any, next: any) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (token) {
    try {
      req.user = jwt.verify(token, JWT_SECRET);
    } catch {}
  }
  next();
}

// ---- Segurança: valida código R antes de executar -----------------------

const BLOCKED_PATTERNS = [
  /system\s*\(/,                     // shell injection
  /shell\s*\(/,
  /Sys\.setenv\s*\(/,
  /\.Call\s*\(/,                     // chamadas C
  /dyn\.load\s*\(/,                  // carregar .so
  /readLines\s*\(\s*"\/(?:etc|proc|sys)/, // leitura de sistema
  /unlink\s*\(\s*"\//, // delete raiz
  /setwd\s*\(\s*"\/(?!tmp)/,        // cd para fora de /tmp
  /Sys\.chmod\s*\(/,
  /pipe\s*\(/,
  /download\.file.+http:\/\/(?!cran\.)/,  // downloads fora do CRAN
];

function validateRCode(code: string): { safe: boolean; reason?: string } {
  for (const pattern of BLOCKED_PATTERNS) {
    if (pattern.test(code)) {
      return { safe: false, reason: `Padrão bloqueado: ${pattern.source}` };
    }
  }
  if (code.length > 100_000) {
    return { safe: false, reason: 'Código muito longo (máx 100KB)' };
  }
  return { safe: true };
}

// ---- Executor Docker -------------------------------------------------------

const R_IMAGE = process.env.R_DOCKER_IMAGE || 'rmobile/r-runtime:latest';
const EXEC_TIMEOUT_MS = 120_000;
const MEMORY_LIMIT = 512 * 1024 * 1024; // 512MB
const CPU_QUOTA = 100_000; // 100% de 1 CPU

async function runRInDocker(code: string, sessionId: string): Promise<{
  stdout: string[];
  stderr: string[];
  warnings: string[];
  plots: string[];
  error: string | null;
  duration: number;
}> {
  const start = Date.now();
  const codeHash = crypto.createHash('sha256').update(code).digest('hex').slice(0, 16);
  const containerName = `r-session-${sessionId}-${codeHash}`;

  // Wrapper R que captura outputs e gráficos
  const wrappedCode = `
options(warn = 1, scipen = 999)
.warnings <- character(0)
.plots <- character(0)

withCallingHandlers({
  tryCatch({
    ${code}
  }, error = function(e) {
    cat("__R_ERROR__:", conditionMessage(e), "\\n", file = stderr())
  })
}, warning = function(w) {
  cat("__R_WARN__:", conditionMessage(w), "\\n", file = stderr())
  invokeRestart("muffleWarning")
})

# Captura plots gerados
if (dev.cur() > 1) {
  tmp <- tempfile(fileext = ".svg")
  tryCatch({
    dev.copy(svg, tmp, width = 7, height = 5)
    dev.off()
    if (file.exists(tmp)) {
      cat("__R_PLOT_START__\\n")
      cat(paste(readLines(tmp), collapse = "\\n"))
      cat("\\n__R_PLOT_END__\\n")
    }
  }, error = function(e) NULL)
}
  `.trim();

  let container: Docker.Container | null = null;

  try {
    container = await docker.createContainer({
      name: containerName,
      Image: R_IMAGE,
      Cmd: ['Rscript', '-e', wrappedCode],
      HostConfig: {
        Memory: MEMORY_LIMIT,
        MemorySwap: MEMORY_LIMIT,
        CpuQuota: CPU_QUOTA,
        CpuPeriod: 100_000,
        NetworkMode: 'none',          // sem rede dentro do container
        ReadonlyRootfs: false,
        SecurityOpt: ['no-new-privileges'],
        Tmpfs: { '/tmp': 'rw,noexec,nosuid,size=100m' },
        AutoRemove: true,
      },
      NetworkDisabled: true,
      WorkingDir: '/tmp',
      User: 'nobody',
      Tty: false,
    });

    await container.start();

    // Timeout via Promise.race
    const outputPromise = new Promise<{ stdout: string; stderr: string }>((resolve) => {
      const chunks: { type: 'stdout' | 'stderr'; data: string }[] = [];

      container!.attach({ stream: true, stdout: true, stderr: true }, (err, stream) => {
        if (err) return resolve({ stdout: '', stderr: err.message });

        let stdoutBuf = '';
        let stderrBuf = '';

        stream?.on('data', (chunk: Buffer) => {
          // Docker multiplexed stream: primeiro byte indica tipo
          const type = chunk[0] === 1 ? 'stdout' : 'stderr';
          const text = chunk.slice(8).toString();
          if (type === 'stdout') stdoutBuf += text;
          else stderrBuf += text;
        });

        stream?.on('end', () => resolve({ stdout: stdoutBuf, stderr: stderrBuf }));
        stream?.on('error', (e) => resolve({ stdout: stdoutBuf, stderr: e.message }));
      });
    });

    const timeoutPromise = new Promise<{ stdout: string; stderr: string }>((_, reject) =>
      setTimeout(() => reject(new Error(`Timeout: execução excedeu ${EXEC_TIMEOUT_MS / 1000}s`)), EXEC_TIMEOUT_MS)
    );

    const { stdout: rawOut, stderr: rawErr } = await Promise.race([outputPromise, timeoutPromise]);

    // Parseia saída estruturada
    const stdout: string[] = [];
    const stderr: string[] = [];
    const warnings: string[] = [];
    const plots: string[] = [];
    let error: string | null = null;

    // Extrai plots do stdout
    const plotRegex = /__R_PLOT_START__\n([\s\S]*?)\n__R_PLOT_END__/g;
    let plotMatch;
    let cleanOut = rawOut;
    while ((plotMatch = plotRegex.exec(rawOut)) !== null) {
      plots.push(plotMatch[1].trim());
      cleanOut = cleanOut.replace(plotMatch[0], '');
    }
    stdout.push(...cleanOut.split('\n').filter(l => l.trim()));

    // Parseia stderr
    rawErr.split('\n').forEach(line => {
      if (line.startsWith('__R_ERROR__:')) {
        error = line.replace('__R_ERROR__:', '').trim();
      } else if (line.startsWith('__R_WARN__:')) {
        warnings.push(line.replace('__R_WARN__:', '').trim());
      } else if (line.trim()) {
        stderr.push(line);
      }
    });

    return { stdout, stderr, warnings, plots, error, duration: Date.now() - start };

  } catch (err: any) {
    return {
      stdout: [], stderr: [], warnings: [], plots: [],
      error: err.message || 'Erro ao executar container',
      duration: Date.now() - start,
    };
  } finally {
    // Garante remoção do container
    if (container) {
      try { await container.stop({ t: 2 }); } catch {}
      try { await container.remove({ force: true }); } catch {}
    }
  }
}

// ---- Cache de resultados no Redis ------------------------------------------

async function getCachedResult(hash: string) {
  try {
    const cached = await redis.get(`exec:${hash}`);
    return cached ? JSON.parse(cached) : null;
  } catch { return null; }
}

async function setCachedResult(hash: string, result: any) {
  try {
    await redis.setEx(`exec:${hash}`, 3600, JSON.stringify(result));
  } catch {}
}

// ---- Rotas ------------------------------------------------------------------

// Health
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Execução R
app.post('/api/execute', execLimiter, optionalAuth, async (req, res) => {
  const { code, sessionId = 'anon' } = req.body;

  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'Campo "code" obrigatório' });
  }

  // Validação de segurança
  const validation = validateRCode(code);
  if (!validation.safe) {
    return res.status(400).json({ error: `Código bloqueado: ${validation.reason}` });
  }

  // Verifica cache
  const hash = crypto.createHash('sha256').update(code).digest('hex');
  const cached = await getCachedResult(hash);
  if (cached) {
    return res.json({ ...cached, cached: true });
  }

  try {
    const result = await runRInDocker(code, sessionId);
    await setCachedResult(hash, result);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Proxy seguro para IA (Anthropic Claude)
app.post('/api/ai/chat', rateLimit({ windowMs: 60_000, max: 30 }), optionalAuth, async (req, res) => {
  const { system, messages } = req.body;

  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Campo "messages" obrigatório' });
  }

  try {
    const response = await anthropic.messages.create({
      model: 'claude-opus-4-5-20251101',
      max_tokens: 4096,
      system: system || 'Você é um especialista em R e estatística.',
      messages: messages.slice(-20), // máx 20 mensagens de contexto
    });

    const content = response.content
      .filter(b => b.type === 'text')
      .map(b => (b as any).text)
      .join('\n');

    res.json({ content });
  } catch (err: any) {
    res.status(500).json({ error: `Erro da IA: ${err.message}` });
  }
});

// Autenticação (simplificada — expandir com PostgreSQL)
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  // TODO: validar contra banco de dados
  if (!email) return res.status(400).json({ error: 'Email obrigatório' });

  const token = jwt.sign({ email, id: crypto.randomUUID() }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

// ---- Inicia servidor --------------------------------------------------------

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`[R Mobile] Backend rodando na porta ${PORT}`);
  console.log(`[R Mobile] Modo: ${process.env.NODE_ENV || 'development'}`);
});

export default app;
